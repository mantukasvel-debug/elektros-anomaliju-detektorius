"""Pasirenkama lokali demonstracija; jokios išorinės API."""
from pathlib import Path
import pandas as pd
import streamlit as st
ROOT=Path(__file__).resolve().parents[1]
st.set_page_config(page_title='Elektros anomalijų detektorius',layout='wide')
st.title('Elektros energijos vartojimo anomalijų detektorius')
st.caption('Mokomasis projektas: sintetiniai matavimai, ne realūs gedimų duomenys')
file=ROOT/'data'/'vartojimas.csv';metrics=ROOT/'data'/'metrikos.csv';rob=ROOT/'data'/'robustumo_santrauka.csv'
if not file.exists():st.error('Pirmiausia paleiskite python code/run.py');st.stop()
df=pd.read_csv(file,parse_dates=['laikas']);days=st.slider('Rodomų pirmųjų dienų skaičius',1,120,14)
st.line_chart(df.head(days*24).set_index('laikas')['kwh'])
st.metric('Žinomų įterptų anomalijų skaičius',int(df.anomalija.sum()))
if metrics.exists():st.subheader('Pagrindinis palyginimas');st.dataframe(pd.read_csv(metrics),hide_index=True)
if rob.exists():st.subheader('Atsparumo eksperimentai');st.dataframe(pd.read_csv(rob),hide_index=True)
st.info('Perspėjimas nėra gedimo diagnozė. Sistema nevaldo elektros įrangos.')
