import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
from sklearn.preprocessing import StandardScaler

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(os.path.join(ROOT,'data'),exist_ok=True); os.makedirs(os.path.join(ROOT,'figures'),exist_ok=True)
rng=np.random.default_rng(42)
n=24*120
idx=pd.date_range('2025-01-01',periods=n,freq='h')
hour=idx.hour.to_numpy(); dow=idx.dayofweek.to_numpy(); weekend=(dow>=5).astype(int)
base=0.65+0.55*((hour>=7)&(hour<=9))+0.9*((hour>=18)&(hour<=22))+0.2*weekend
cons=np.maximum(0.1,base+rng.normal(0,0.12,n))
y=np.zeros(n,dtype=int)
# 5% anomalijų: dideli šuoliai, kritimai ir ilgesnis neįprastas vartojimas
ids=rng.choice(np.arange(24,n),size=135,replace=False)
y[ids]=1
half=len(ids)//2
cons[ids[:half]]+=rng.uniform(2.0,4.0,half)
cons[ids[half:]]=np.maximum(0.02,cons[ids[half:]]*rng.uniform(0.01,0.12,len(ids)-half))
df=pd.DataFrame({'laikas':idx,'kwh':cons,'valanda':hour,'savaites_diena':dow,'anomalija':y})
df.to_csv(os.path.join(ROOT,'data','vartojimas.csv'),index=False)
# Chronologinis skaidymas; 70% mokymui, 30% testui. Mokymas be žymų.
split=int(n*.7)
# Valandai būdingas etalonas iš mokymo dalies
med=df.iloc[:split].groupby('valanda')['kwh'].median()
mad=df.iloc[:split].assign(dev=lambda d:abs(d.kwh-d.valanda.map(med))).groupby('valanda')['dev'].median().clip(lower=.05)
z=((df.kwh-df.valanda.map(med)).abs()/(1.4826*df.valanda.map(mad))).to_numpy()
baseline=(z>3.5).astype(int)
# Neprižiūrimas pažangesnis modelis: apmokomas su požymiais, be etikečių
X=pd.DataFrame({'kwh':df.kwh,'val_sin':np.sin(2*np.pi*hour/24),'val_cos':np.cos(2*np.pi*hour/24),'savaitgalis':weekend,'nuokrypis':df.kwh-df.valanda.map(med)})
sc=StandardScaler().fit(X.iloc[:split]); Xs=sc.transform(X)
model=IsolationForest(n_estimators=250,contamination=.05,random_state=42,n_jobs=1).fit(Xs[:split])
proposed=(model.predict(Xs)==-1).astype(int)
rows=[]
for name,pred in [('Bazinis: valandinis MAD',baseline),('Patobulintas: Isolation Forest',proposed)]:
    yy=y[split:]; pp=pred[split:]
    rows.append({'modelis':name,'tikslumas_precision':precision_score(yy,pp,zero_division=0),'jautrumas_recall':recall_score(yy,pp,zero_division=0),'F1':f1_score(yy,pp,zero_division=0),'TN':int(confusion_matrix(yy,pp,labels=[0,1])[0,0]),'FP':int(confusion_matrix(yy,pp,labels=[0,1])[0,1]),'FN':int(confusion_matrix(yy,pp,labels=[0,1])[1,0]),'TP':int(confusion_matrix(yy,pp,labels=[0,1])[1,1])})
res=pd.DataFrame(rows); res.to_csv(os.path.join(ROOT,'data','metrikos.csv'),index=False)
print(res.to_string(index=False))
plt.rcParams.update({'font.size':10})
fig,ax=plt.subplots(figsize=(10,3.4)); ax.plot(idx[:240],cons[:240],lw=1,label='Vartojimas (kWh)'); aa=np.where(y[:240]==1)[0];ax.scatter(idx[aa],cons[aa],color='#d35400',s=24,label='Įterptos anomalijos');ax.set_ylabel('kWh per valandą');ax.legend();fig.autofmt_xdate();fig.tight_layout();fig.savefig(os.path.join(ROOT,'figures','01_vartojimas.png'),dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,3.6)); xx=np.arange(2);w=.24
for j,(col,label) in enumerate([('tikslumas_precision','Precision'),('jautrumas_recall','Recall'),('F1','F1')]):ax.bar(xx+(j-1)*w,res[col],width=w,label=label)
ax.set_xticks(xx,['Bazinis MAD','Isolation Forest']);ax.set_ylim(0,1.05);ax.legend();ax.set_ylabel('Rodiklio reikšmė');fig.tight_layout();fig.savefig(os.path.join(ROOT,'figures','02_metrikos.png'),dpi=170);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(8,3.5))
for ax,r in zip(axs,rows):
    cm=np.array([[r['TN'],r['FP']],[r['FN'],r['TP']]])
    ax.imshow(cm,cmap='Blues');ax.set_title(r['modelis'].split(':')[0]);ax.set_xticks([0,1],['Norma','Anomalija']);ax.set_yticks([0,1],['Norma','Anomalija']);ax.set_xlabel('Prognozė');ax.set_ylabel('Tikroji klasė')
    for (i,j),v in np.ndenumerate(cm):ax.text(j,i,str(v),ha='center',va='center',color='black')
fig.tight_layout();fig.savefig(os.path.join(ROOT,'figures','03_matricos.png'),dpi=170);plt.close(fig)
