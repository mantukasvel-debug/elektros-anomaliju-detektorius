"""Nepriklausomi pakartojimai; nenaudoja testinių žymų modeliams derinti."""
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_score,recall_score,f1_score
ROOT=Path(__file__).resolve().parents[1]
rows=[]
for scenario in ['ryskios','subtilios']:
 for seed in [11,22,33,44,55]:
  rng=np.random.default_rng(seed); n=2880; idx=pd.date_range('2025-01-01',periods=n,freq='h'); h=idx.hour.to_numpy(); wd=idx.dayofweek.to_numpy(); wk=(wd>=5).astype(int)
  base=.65+.55*((h>=7)&(h<=9))+.9*((h>=18)&(h<=22))+.2*wk
  x=np.maximum(.1,base+rng.normal(0,.12,n)); y=np.zeros(n,dtype=int)
  ids=rng.choice(np.arange(24,n),135,replace=False);y[ids]=1; half=len(ids)//2
  if scenario=='ryskios':
   x[ids[:half]]+=rng.uniform(2,4,half);x[ids[half:]]=np.maximum(.02,x[ids[half:]]*rng.uniform(.01,.12,len(ids)-half))
  else:
   x[ids[:half]]+=rng.uniform(.25,.65,half);x[ids[half:]]=np.maximum(.02,x[ids[half:]]*rng.uniform(.55,.8,len(ids)-half))
  df=pd.DataFrame({'kwh':x,'h':h}); split=int(n*.7)
  med=df.iloc[:split].groupby('h').kwh.median();mad=df.iloc[:split].assign(dev=lambda d:abs(d.kwh-d.h.map(med))).groupby('h').dev.median().clip(lower=.05)
  z=abs(df.kwh-df.h.map(med))/(1.4826*df.h.map(mad)); p1=(z.to_numpy()>3.5).astype(int)
  X=np.column_stack([x,np.sin(2*np.pi*h/24),np.cos(2*np.pi*h/24),wk,x-df.h.map(med).to_numpy()]); sc=StandardScaler().fit(X[:split]); Xs=sc.transform(X)
  clf=IsolationForest(n_estimators=250,contamination=.05,random_state=42,n_jobs=1).fit(Xs[:split]);p2=(clf.predict(Xs)==-1).astype(int)
  for name,p in [('MAD',p1),('Isolation Forest',p2)]:
   yy=y[split:];pp=p[split:]
   rows.append({'scenarijus':scenario,'sekla':seed,'modelis':name,'precision':precision_score(yy,pp,zero_division=0),'recall':recall_score(yy,pp,zero_division=0),'F1':f1_score(yy,pp,zero_division=0),'klaidingi_perspejimai':int(((yy==0)&(pp==1)).sum()),'neaptiktos_anomalijos':int(((yy==1)&(pp==0)).sum())})
df=pd.DataFrame(rows);df.to_csv(ROOT/'data'/'robustumo_bandymu_rezultatai.csv',index=False)
summary=df.groupby(['scenarijus','modelis']).agg(F1_vidurkis=('F1','mean'),F1_sd=('F1','std'),precision_vidurkis=('precision','mean'),recall_vidurkis=('recall','mean'),FP_vidurkis=('klaidingi_perspejimai','mean')).reset_index();summary.to_csv(ROOT/'data'/'robustumo_santrauka.csv',index=False)
print(summary.to_string(index=False))
fig,ax=plt.subplots(figsize=(9,4));labels=[];means=[];errs=[]
for _,r in summary.iterrows():labels.append(r.scenarijus+' / '+r.modelis);means.append(r.F1_vidurkis);errs.append(r.F1_sd)
ax.barh(labels,means,xerr=errs,capsize=4);ax.set_xlim(0,1.05);ax.set_xlabel('F1 vidurkis ± standartinis nuokrypis (5 sėklos)');fig.tight_layout();fig.savefig(ROOT/'figures'/'04_robustumas.png',dpi=170);plt.close(fig)
