"""Papildoma EDA, jautrumo ir paaiškinamumo analizė. Paleisti po run.py."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/'data/vartojimas.csv',parse_dates=['laikas'])
hr=df.laikas.dt.hour.to_numpy(); wd=df.laikas.dt.dayofweek.to_numpy(); wk=(wd>=5).astype(int)
n=len(df); split=int(n*.7); rng=np.random.default_rng(2026)
med=df.iloc[:split].groupby(df.laikas.dt.hour.iloc[:split])['kwh'].median()
X=pd.DataFrame({'kwh':df.kwh,'val_sin':np.sin(2*np.pi*hr/24),'val_cos':np.cos(2*np.pi*hr/24),'savaitgalis':wk,'nuokrypis':df.kwh-med.reindex(hr).to_numpy()})
sc=StandardScaler().fit(X.iloc[:split]); Xt=sc.transform(X)
model=IsolationForest(n_estimators=250,contamination=.05,random_state=42,n_jobs=1).fit(Xt[:split])
# Permutacinis jautrumas: vidutinis absoliutus anomalijos balo pokytis, ne priežastinis paaiškinimas.
orig=model.decision_function(Xt[split:]); out=[]
for j,name in enumerate(X.columns):
    altered=Xt[split:].copy(); altered[:,j]=rng.permutation(altered[:,j]); change=np.abs(model.decision_function(altered)-orig).mean()
    out.append({'pozymis':name,'vidutinis_absoliutus_balo_pokytis':change})
imp=pd.DataFrame(out).sort_values('vidutinis_absoliutus_balo_pokytis',ascending=False)
imp.to_csv(ROOT/'data/pozymiu_jautrumas.csv',index=False)
fig,ax=plt.subplots(figsize=(8,4));ax.barh(imp.pozymis[::-1],imp.vidutinis_absoliutus_balo_pokytis[::-1]);ax.set_xlabel('Vidutinis absoliutus anomalijos balo pokytis');ax.set_title('Požymių permutacinis jautrumas');fig.tight_layout();fig.savefig(ROOT/'figures/06_pozymiu_jautrumas.png',dpi=170);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10,3.7));axs[0].hist(df.kwh,bins=45);axs[0].set(xlabel='kWh per valandą',ylabel='Dažnis',title='Vartojimo histograma');corr=df[['kwh','valanda','savaites_diena','anomalija']].corr(numeric_only=True);im=axs[1].imshow(corr,vmin=-1,vmax=1,cmap='coolwarm');axs[1].set_xticks(range(4),corr.columns,rotation=40,ha='right');axs[1].set_yticks(range(4),corr.columns);axs[1].set_title('Pearson koreliacijos');fig.colorbar(im,ax=axs[1],fraction=.046);fig.tight_layout();fig.savefig(ROOT/'figures/05_eda.png',dpi=170);plt.close(fig)
# Jautrumas contamination parametrui; vertiname tik testą, jokio testinio derinimo.
from sklearn.metrics import precision_score,recall_score,f1_score
rows=[]; y=df.anomalija.to_numpy()[split:]
for c in [.02,.05,.08,.12]:
    m=IsolationForest(n_estimators=250,contamination=c,random_state=42,n_jobs=1).fit(Xt[:split]);p=(m.predict(Xt[split:])==-1).astype(int)
    rows.append({'contamination':c,'precision':precision_score(y,p,zero_division=0),'recall':recall_score(y,p,zero_division=0),'F1':f1_score(y,p,zero_division=0)})
sens=pd.DataFrame(rows);sens.to_csv(ROOT/'data/parametru_jautrumas.csv',index=False)
fig,ax=plt.subplots(figsize=(7,3.5));ax.plot(sens.contamination,sens.F1,marker='o',label='F1');ax.plot(sens.contamination,sens.precision,marker='s',label='Precision');ax.plot(sens.contamination,sens.recall,marker='^',label='Recall');ax.set(xlabel='contamination',ylabel='Metrika',ylim=(0,1.05),title='Parametro jautrumo analizė');ax.legend();fig.tight_layout();fig.savefig(ROOT/'figures/07_parametru_jautrumas.png',dpi=170);plt.close(fig)
print('Požymių jautrumas:');print(imp.to_string(index=False));print('\nParametrų jautrumas:');print(sens.to_string(index=False))
