# Elektros energijos vartojimo anomalijų detektorius

Atkuriamas mokomasis projektas. **Duomenys sintetiniai; jie nepatvirtina realių elektros gedimų.** Nenaudojami mokami ar uždari API.

## Paleidimas

Python 3.10+:

```bash
python -m pip install -r requirements.txt
python code/run.py
python code/robustumas.py
streamlit run code/app.py
```

Pagrindinis bandymas su sėkla 42: MAD F1 1,000; Isolation Forest F1 0,947. Atsparumo bandymas: 5 sėklos × 2 scenarijai, rezultatai `data/robustumo_santrauka.csv`. Pirmoji komanda sukuria CSV ir tris grafikus, antroji – papildomą lentelę ir ketvirtą grafiką. Trečioji atidaro neprivalomą lokalią demonstracinę sąsają.

## Duomenų ir rezultatų kilmė

`code/run.py` generuoja 2 880 valandinių įrašų; `code/robustumas.py` generuoja atskirus bandymus. Nėra tikrų vartotojų duomenų. Testinių žymų nenaudojama modeliams mokyti. Metrikos apskaičiuojamos vykdant kodą, o ne įrašomos ranka.

## GitHub

Įkelkite šio katalogo turinį į savo viešą saugyklą. **Šiame archyve GitHub nuorodos nėra**, nes saugykla dar nesukurta.

## Gynimas

Paaiškinkite, kodėl MAD gerai aptinka ryškius šuolius, o Isolation Forest subtilių anomalijų scenarijuje turi geresnį jautrumą, bet daugiau klaidingų perspėjimų. Parodykite `data/` ir `figures/` failus bei lokalią sąsają.

## Papildomi tyrimai (aukštesniems vertinimo kriterijams)

Paleidus `python code/run.py`, vykdykite `python code/papildoma_analize.py`.
Sugeneruojami `figures/05_eda.png`, `06_pozymiu_jautrumas.png`,
`07_parametru_jautrumas.png` ir atitinkami CSV failai `data/` kataloge.
Požymių permutacinis jautrumas nėra priežastinis aiškinimas ar SHAP.
Jautrumo bandyme testiniai duomenys naudojami tik palyginimui, ne galutiniam
hiperparametrų parinkimui. Visi matavimai sintetiniai.
